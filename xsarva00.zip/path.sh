#!/bin/bash

. sfc_env/bin/activate

