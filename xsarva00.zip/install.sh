#!/usr/bin/bash

python3 -m venv sfc_env
. sfc_env/bin/activate
pip install -r requirements.txt
